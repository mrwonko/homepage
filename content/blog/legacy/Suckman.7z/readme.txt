Suckman - the first game made by Mr. Wonko

Just follow the ingame-instructions.

Credits:
-NeHe for his great Open GL tutorial on
http://nehe.gamedev.net. Without you this game would'nt've
been created. (was that bad?) 

-Gregor V. for helping me learning Open GL, e.g. telling
me how to let a game run at the same speed at every
computer.

Changelog:

1.2	17.02.2006
	5 Difficulty-levels:
	 -lvl1	60 seconds time, 2 squares
	 -lvl2	30 seconds time
	 -lvl3	20 seconds time
	 -lvl4	15 seconds time
	 -lvl5	12 seconds time
	Last level is printed on the screen so you can't
	say you got 28 points at lvl5 if you had played
	lvl1 ;)

	Background image - you can change it by putting
	a 512*512 (or any other power of 2 by power of 2)
	.bmp file in the Maps directory and changing the
	name in the mapname.txt file.

	The game has now an icon.


1.1	16.02.2006
	A new startscreen with the name of the game and
	some instructions

	Font - you no longer have to count the lines in
	order to know how many points you have :P


1.0	16.02.2006
	The game is finaly playable. While you're playing
	there are lines which show you how much time is
	left. After the game you can count the lines on
	the appearing screen in order to know how many
	points you just got.

	This version was never released. (I just sent it
	to some people in order to get feedback)