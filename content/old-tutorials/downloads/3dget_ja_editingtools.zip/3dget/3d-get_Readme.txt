Inofficial JK3-Editing Kit by 3D GET.
=====================================
www.3d-get.de
www.darth-arth.de


Content:
========

Tool			Maker
------------------------------------------------
ja-shaderlists 		Zero/darth Arth
mp & SP Entities	Zero/Darth Arth
Player-Modeling tools	Seb-Crea
sky_portal Tutorial	Zero (incl. map-file)
Siege-Mode, Keys	Zero

============================================================================
THIS JK3-EDITING SDK IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION, RAVEN
OR LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS TM & � LUCASARTS 
ENTERTAINMENT COMPANY LLC AND/OR ITS LICENSORS
